/* ======================================================================
 *   Excerpted from Hipparchus Main Header (hipparch.h)
 *   with the express permission of Geodyssey Limited.
 *
 *   (c) Copyright Geodyssey Limited, 1992, 2005.
 * ====================================================================== */

#ifndef HIPPLITE_H
#define HIPPLITE_H

/* Redefine this as required to make it a 4-byte integer on all platforms */

typedef int hipp4_int;

/* ---------------------------------------------------------------------- */

/* Hipparchus Useful Numeric Constants */

/* angular constants */
#define PI       3.14159265358979323846
#define PIHALF   1.57079632679489661923
#define DEG2RAD  (PI / 180.0)
#define RAD2DEG  (180.0 / PI)

/* Radius of the planet Earth. Very approximate, can be used for
   preliminary values in iterations and approximate graphics. */
#define ERTHRAD    6371007.1808

/* Resolution threshold values, corresponding to approximately
   1/10th of a millimeter on Earth's surface */

/* Global radian angle */
#define FUZZA  4.e-12

/* Square of two orthogonal direction cosines */
#define FUZZC  2.458e-22

/* As above, where the precision loss is possible */
#define FUZZCC 2.458e-14

/* ---------------------------------------------------------------------- */

/* Hipparchus Floating Point Data Definitions */

/* direction cosine component data type definition: */

typedef double ijk_type;

/* "Hipparchus float" - miscellaneous floating point items: */

typedef double hf_type;

/* angle in radian measurement data type definition: */

typedef double ar_type;

/* ---------------------------------------------------------------------- */

/* Hipparchus Distance Data Type Definitions */

/* arc_ and chord_ are respective distances on or near the surface of the
   sphere, in this system usually on the unit conformal reference sphere. */
typedef double   arc_dist;
typedef double chord_dist;

/* csq_dist is the square of the spherical chord. Since the squares of (any)
   two numbers compare the same as the numbers themselves - likewise for the
   chord and the arc - and since the square chord can be derived from (most)
   numerical location representations easier than any other distance
   measurement, this distance measurement is used in most high-volume
   distance comparisons.                                                  */
typedef double  csq_dist;

/* ---------------------------------------------------------------------- */

/* Hipparchus Math Library Function Redefinitions */

/* Math library floating point functions are redefined in order
   potentially to implement a different width for floating point items ...*/

#define   H1_atan2(c, s)             atan2((c), (s))
#define   H1_cos(c)                  cos(c)
#define   H1_fabs(c)                 fabs(c)
#define   H1_sin(c)                  sin(c)
#define   H1_sqrt(c)                 sqrt(c)

/* ---------------------------------------------------------------------- */

/* Angle in radians in the range of -PI < a < +PI can be packed in a
   4-byte integer, with a resolution of about 1cm on the Earth's surface: */

#define I4A_UNDEF      -2147483647
#define I4A_SCALE       2147483640.0
#define H1_AngOfI4(i)  ((((hf_type)i)/I4A_SCALE) * PI)
#define H1_I4OfAng(r)  ((hipp4_int)((r/PI) * I4A_SCALE))

/* ---------------------------------------------------------------------- */

/* Hipparchus Lat-Long Point Coordinates */

/* Separate definitions for Hipparchus sphere and ellipsoid make possible
   compiler checks of calling sequences, reducing the risk of unintentional
   coordinate system mismatch. */

struct ltln {            /* Generic latitude-longitude point (in radians) */
   ar_type lat;
   ar_type lng;
   };

/* ---------------------------------------------------------------------- */

/* Hipparchus Vector Point Coordinates */

/* Separate definitions for Hipparchus sphere and ellipsoid
   make possible compiler checks of calling sequences, to
   reduce the risk of un-intentional reference surface
   (coordinate system) mis-match. */

struct vct3 {    /* Generic spatial vector (normalized direction cosines) */
   ijk_type di;
   ijk_type dj;
   ijk_type dk;
   };

struct cdc_h {          /* CDC (concise direction cosines), 4-byte integer */
   hipp4_int u;
   hipp4_int v;
   };

/* ---------------------------------------------------------------------- */

/* Hipparchus Distance as Macro */

#define H3_HipparchDist(pa, pb) \
    (((pb)->di - (pa)->di) * ((pb)->di - (pa)->di) + \
     ((pb)->dj - (pa)->dj) * ((pb)->dj - (pa)->dj) + \
     ((pb)->dk - (pa)->dk) * ((pb)->dk - (pa)->dk))

/* ---------------------------------------------------------------------- */

/* Hipparchus Function Prototypes */

void     h0_Dcos3ToCdcH(const struct vct3 *, struct cdc_h *);
void     h0_CdcHToDcos3(const struct cdc_h *, struct vct3 *);
void     h1_Dcos3ToLatLong(const struct vct3 *, struct ltln *);
void     h1_LatLongToDcos3(const struct ltln *, struct vct3 *);
arc_dist h3_HipparchDistToArcApprox(csq_dist);

#endif
