Readme.txt for LABOMBAY
Last updated: 2000/03/22

LABOMBAY is a program demonstrating the convenience and speed of a
concise direction cosine form of global geographic coordinates.
(Programmer: Hrvoje Lukatela, Geodyssey Limited, March 2000).

This code is offered as an illustration of a mathematical concept.
It is supplied without warranty and presented without any
restrictions on its use.

"Direction cosines" refers to a set of three cosines that may be used
to specify a vector in space. Like latitude and longitude, direction
cosines may be used to specify the normal to the ellipsoid surface -
which defines a location of a point on the surface of the Earth.

"Concise direction cosines" (CDC) is a global coordinate format which
retains only two out of these three (normalized) direction cosines.
This is possible because the third cosine can always be recomputed from
the other two since the sum of squares of all three equals 1.

In this implementation, the two retained direction cosines are scaled
to two 4-byte integers, the least significant two bits of which
identify which of the three cosines has been dropped, and its sign.
In this format, global geographic positions can be specified with a
ground resolution of about one centimeter, anywhere, equivalent to
that obtainable using similar encoding for latitude and longitude.

In keeping with the philosophy of the Hipparchus Library,
CDC coordinates are specified in a form of a structure {u,v},
analogous to {x,y} or {lat,long}. An application may however
consider them to be an array of two elements of integer type.

This form of geographic coordinate encoding is particularly useful in
instances where computational efficiency is important. The advantage
lies in the computational simplicity of the vector algebra required to
determine relationships such as distance or direction, as compared to
similar use of angular specifiers (lat/long) requiring calls to the
trancendental functions such as sine, cosine, arctangent, etc.

The problem scenario used to demonstrate the speed advantage of CDC's
is straightforward.  While it might lack in the realism, it is both
simple to describe and results in code that does not cloud the
central proposition: For spatial applications that are continental or
global in scope, it is advantageous if the coordinates are recorded
not as angular latitude and longitude, but in vector form.

We assume a permanent database of point locations (airports of
the world) and a transient, problem-oriented set of way-points
on a fligh path between two cities, Bombay and Los Angeles.
The flight path is illustrated by the file labombay.png,
which may be viewed by any recent net browser.

For each way-point on the flight path (representing, say, flight
positions at successive five minute intervals during the flight),
we want to find the nearest airport.

In order to eliminate the influence of external storage access,
the application data is loaded into memory arrays.

For each set, point coordinates are read loaded in vector (CDC) form,
then converted and loaded in an alternate compact (lat/long) form.
(Both forms retaining a ground resolution of about a centimeter).

Two sets of nested loops are performed and timed:

In the first set of loops the proximities are determined using
coordinates in CDC format and vector algebra, while in the second,
proximities are determined using coordinates in lat/long form and
conventional spherical trigonometry.

For each set of loops, a record is kept of the nearest airport along the
flight line, and subsequently listed as a time-ordered set of airports.

Finally, the computation times for each approach are compared and
reported.

Notes:

The great circle is computed using the cosine of the angle; this
lacks the precision in the case of small distances; it is however
simpler and faster than the sine computation based on Gauss-Delambre's
equations.

The airport location file is used for illustrative purposes only;
without any suggestion that it is either correct or complete.

End of readme.
