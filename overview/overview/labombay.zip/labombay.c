/* ======================================================================
 * LABOMBAY is a program demonstrating the convenience and speed of a
 * concise direction cosine form of global geographic coordinates.
 * (Programmer: Hrvoje Lukatela, Geodyssey Limited, March 2000).
 *
 * This code is offered as an illustration of a mathematical concept.
 * It is supplied without warranty and presented without any
 * restrictions on its use.
 *
 * "Direction cosines" refers to a set of three cosines that may be used
 * to specify a vector in space. Like latitude and longitude, direction
 * cosines may be used to specify the normal to the ellipsoid surface -
 * which defines a location of a point on the surface of the Earth.
 *
 * "Concise direction cosines" (CDC) is a global coordinate format which
 * retains only two out of these three (normalized) direction cosines.
 * This is possible because the third cosine can always be recomputed from
 * the other two since the sum of squares of all three equals 1.
 *
 * In this implementation, the two retained direction cosines are scaled
 * to two 4-byte integers, the least significant two bits of which
 * identify which of the three cosines has been dropped, and its sign.
 * In this format, global geographic positions can be specified with a
 * ground resolution of about one centimeter, anywhere, equivalent to
 * that obtainable using similar encoding for latitude and longitude.
 *
 * In keeping with the philosophy of the Hipparchus Library,
 * CDC coordinates are specified in a form of a structure {u,v},
 * analogous to {x,y} or {lat,long}. An application may however
 * consider them to be an array of two elements of integer type.
 *
 * This form of geographic coordinate encoding is particularly useful in
 * instances where computational efficiency is important. The advantage
 * lies in the computational simplicity of the vector algebra required to
 * determine relationships such as distance or direction, as compared to
 * similar use of angular specifiers (lat/long) requiring calls to the
 * trancendental functions such as sine, cosine, arctangent, etc.
 *
 * The problem scenario used to demonstrate the speed advantage of CDC's
 * is straightforward.  While it might lack in the realism, it is both
 * simple to describe and results in code that does not cloud the
 * central proposition: For spatial applications that are continental or
 * global in scope, it is advantageous if the coordinates are recorded
 * not as angular latitude and longitude, but in vector form.
 *
 * We assume a permanent database of point locations (airports of
 * the world) and a transient, problem-oriented set of way-points
 * on a fligh path between two cities, Bombay and Los Angeles.
 *
 * For each way-point on the flight path (representing, say, flight
 * positions at successive five minute intervals during the flight),
 * we want to find the nearest airport.
 *
 * In order to eliminate the influence of external storage access,
 * the application data is loaded into memory arrays.
 *
 * For each set, point coordinates are read loaded in vector (CDC) form,
 * then converted and loaded in an alternate compact (lat/long) form.
 * (Both forms retaining a ground resolution of about a centimeter).
 *
 * Two sets of nested loops are performed and timed:
 *
 * In the first set of loops the proximities are determined using
 * coordinates in CDC format and vector algebra, while in the second,
 * proximities are determined using coordinates in lat/long form and
 * conventional spherical trigonometry.
 *
 * For each set of loops, a record is kept of the nearest airport along the
 * flight line, and subsequently listed as a time-ordered set of airports.
 *
 * Finally, the computation times for each approach are compared and
 * reported.
 *
 * Notes:
 *
 * The great circle is computed using the cosine of the angle; this
 * lacks the precision in the case of small distances; it is however
 * simpler and faster than the sine computation based on Gauss-Delambre's
 * equations.
 *
 * The airport location file is used for illustrative purposes only;
 * without any suggestion that it is either correct or complete.
 *
 * ====================================================================== */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <io.h>
#include <assert.h>
#include <math.h>
#include <time.h>
#include <hipplite.h>

#define FLIGHT_LINE_FILE "flightline.lnc"
#define AIRPORTS_FILE    "airports.ptc"

#define TOKEN_DEL          " \t\n"                   /* strtok delimiters */
#define LINE_LENGTH            512
#define WAYPOINTS_MAX         1000              /* we know the size of... */
#define AIRPORTS_MAX         13050            /* ...those test/demo files */

#define DBLHUGE  1.79769313486230e+308

hf_type gcProx(struct ltln *, struct ltln *);

/* To convert clock ticks into time measure (CLK_TCK == CLOCKS_PER_SEC) */
#define H0_Tic2Sec(t) ((double)(t)/(double)CLOCKS_PER_SEC)
#define H0_Hours(t)   ((int)(H0_Tic2Sec(t) / 3600.0))
#define H0_Minutes(t) ((int)(fmod(H0_Tic2Sec(t), 3600.0) / 60.0))
#define H0_Seconds(t) (fmod(H0_Tic2Sec(t), 60.0))

struct conciseLatLong {
   hipp4_int lat;
   hipp4_int lng;
   };

int main() {
   FILE    *inFpL;
   FILE    *inFpA;
   int      i, j, n, nA, nL;
   char     inLine[LINE_LENGTH + 2];
   char    *pa;
   struct   cdc_h airportCdcLocn[AIRPORTS_MAX];
   struct   conciseLatLong airportLatLngLocn[AIRPORTS_MAX];
   char    *names[AIRPORTS_MAX];
   struct   cdc_h wayPointsCdcLocn[WAYPOINTS_MAX];
   struct   conciseLatLong wayPointsLatLngLocn[WAYPOINTS_MAX];
   int      ix[WAYPOINTS_MAX];
   double   ad[WAYPOINTS_MAX];
   struct   vct3 dcA, dcL;
   struct   ltln llA, llL;
   double   prox, proxMin, tC, tL;
   clock_t  ticks_0, ticks_cdc, ticks_ll;
/* ------------------------------------------------------------------------ */
   if (access(AIRPORTS_FILE, 4)) fprintf(stderr, "Can't find file %s\n", AIRPORTS_FILE);
   if (access(FLIGHT_LINE_FILE, 4)) fprintf(stderr, "Can't find file %s\n", FLIGHT_LINE_FILE);

   inFpA = fopen(AIRPORTS_FILE, "rt");            /* records are: u, v, name */
   assert(inFpA);
   inFpL = fopen(FLIGHT_LINE_FILE, "rt");    /* records are: u, v, timestamp */
   assert(inFpL);

   fprintf(stderr, "Reading %s\n", AIRPORTS_FILE);
   nA = 0;                                    /* read, count, store airports */
   while (fgets(inLine, LINE_LENGTH, inFpA)) {        /* traverse input file */
      if ((*inLine == ';') || (*inLine == '*')) continue;
      assert(nA < AIRPORTS_MAX);
      pa = strtok(inLine, TOKEN_DEL);       /* extract 1st vector coord item */
      airportCdcLocn[nA].u = atoi(pa);
      pa = strtok(NULL, TOKEN_DEL);         /* extract 2nd vector coord item */
      airportCdcLocn[nA].v = atoi(pa);
      pa = strtok(NULL, "\n");                       /* extract airport name */
      names[nA] = strdup(pa);
      h0_CdcHToDcos3(airportCdcLocn + nA, &dcA);        /* expand to doubles */
      h1_Dcos3ToLatLong(&dcA, &llA);                  /* convert to lat/long */
      airportLatLngLocn[nA].lat = H1_I4OfAng(llA.lat);     /* store it in... */
      airportLatLngLocn[nA].lng = H1_I4OfAng(llA.lng);    /* ...compact form */
      nA++;
      }
   fprintf(stderr, "Input airports: %d\n", nA);

   fprintf(stderr, "Reading %s\n", FLIGHT_LINE_FILE);
   nL = 0;           /* read, count, store way-points - similar to the above */
   while (fgets(inLine, LINE_LENGTH, inFpL)) {
      if ((*inLine == ';') || (*inLine == '*')) continue;
      assert(nL < WAYPOINTS_MAX);
      pa = strtok(inLine, TOKEN_DEL);
      wayPointsCdcLocn[nL].u = atoi(pa);
      pa = strtok(NULL, TOKEN_DEL);
      wayPointsCdcLocn[nL].v = atoi(pa);
      h0_CdcHToDcos3(wayPointsCdcLocn + nL, &dcL);
      h1_Dcos3ToLatLong(&dcL, &llL);
      wayPointsLatLngLocn[nL].lat = H1_I4OfAng(llL.lat);
      wayPointsLatLngLocn[nL].lng = H1_I4OfAng(llL.lng);
      nL++;
      }
   fprintf(stderr, "Input flightline points: %d\n", nL);
   fclose(inFpL);
   fclose(inFpA);
   fprintf(stderr, "Number of proximity tests: %d\n\n", nL * nA);

/* Following would let us inspect the loaded arrays in conventional coodrs. */
/* for (i = 0; i < nL; i++) {
      h0_CdcHToDcos3(wayPointsCdcLocn + i, &dcL);
      h1_Dcos3ToLatLong(&dcL, &llL);
      fprintf(stderr, "%9.5f %10.5f\n", RAD2DEG * llL.lat, RAD2DEG * llL.lng);
      llL.lat = H1_AngOfI4(wayPointsLatLngLocn[i].lat);
      llL.lng = H1_AngOfI4(wayPointsLatLngLocn[i].lng);
      fprintf(stderr, "%9.5f %10.5f\n", RAD2DEG * llL.lat, RAD2DEG * llL.lng);
      }
   for (j = 0; j < nA; j++) {
      h0_CdcHToDcos3(airportCdcLocn + j, &dcA);
      h1_Dcos3ToLatLong(&dcA, &llA);
      fprintf(stderr, "%9.5f %10.5f %s\n", RAD2DEG * llA.lat, RAD2DEG * llA.lng, names[j]);
      llA.lat = H1_AngOfI4(airportLatLngLocn[j].lat);
      llA.lng = H1_AngOfI4(airportLatLngLocn[j].lng);
      fprintf(stderr, "%9.5f %10.5f\n", RAD2DEG * llA.lat, RAD2DEG * llA.lng);
      }
 */
   fprintf(stderr, "==== Find nearest airports to the points ======\n");
   fprintf(stderr, "==== along Bombay-Los Angeles flight path =====\n");
   fprintf(stderr, "==== (test proximity using CDC coordinates) ===\n");

   ticks_0 = clock();                                         /* start clock */
   for (i = 0; i < nL; i++) {                         /* traverse flightline */
      if (i%10 == 0) fprintf(stderr, "%d\r", i);
      h0_CdcHToDcos3(wayPointsCdcLocn + i, &dcL);    /* use vector way-point */
      proxMin = DBLHUGE;
      ix[i] = -1;
      for (j = 0; j < nA; j++) {                        /* traverse airports */
         h0_CdcHToDcos3(airportCdcLocn + j, &dcA);    /* use vector airtport */
         prox = H3_HipparchDist(&dcL, &dcA);                 /* chord square */
         if (prox < proxMin) {                 /* proximity: closest so far? */
            ix[i] = j;
            proxMin = prox;
            }
         }
      assert(ix[i] != -1);
      ad[ix[i]] = h3_HipparchDistToArcApprox(proxMin); /* save ang. distance */
      }
   ticks_cdc = clock() - ticks_0;                              /* stop clock */
   n = 0;
   fprintf(stderr, "%s\n", names[ix[0]]);        /* report time-ordered list */
   for (i = 1; i < nL; i++) {                       /* of unique airports at */
      if (ix[i] == ix[i - 1]) continue;           /* regular intervals along */
      fprintf(stderr, "%s\n", names[ix[i]]);               /* the flightline */
      n++;
      }
   fprintf(stdout, "[Duration %d:%02d:%06.3f]\n\n", H0_Hours(ticks_cdc), H0_Minutes(ticks_cdc), H0_Seconds(ticks_cdc));
/* Full report: name and distance to the closest airport for each way-point  */
/* for (i = 0; i < nL; i++) fprintf(stderr, "%s %8.1f\n", names[ix[i]], ERTHRAD * ad[ix[i]]); */

   fprintf(stderr, "==== Find nearest airports to the points ======\n");
   fprintf(stderr, "==== along Bombay-Los Angeles flight path =====\n");
   fprintf(stderr, "= (test proximity using lat/long coordinates) =\n");

   ticks_0 = clock();      /* similar to the previous loop, except as noted: */                              /* start clock */
   for (i = 0; i < nL; i++) {
      if (i%10 == 0) fprintf(stderr, "%d\r", i);
      llL.lat = H1_AngOfI4(wayPointsLatLngLocn[i].lat);     /* use way-point */
      llL.lng = H1_AngOfI4(wayPointsLatLngLocn[i].lng);   /* lat/long coords */
      proxMin = -DBLHUGE;
      ix[i] = -1;
      for (j = 0; j < nA; j++) {
         llA.lat = H1_AngOfI4(airportLatLngLocn[j].lat);      /* use airport */
         llA.lng = H1_AngOfI4(airportLatLngLocn[j].lng);  /* lat/long coords */
         prox = gcProx(&llL, &llA);          /* cosine of great circle angle */
         if (prox > proxMin) {
            ix[i] = j;
            proxMin = prox;
            }
         }
      assert(ix[i] != -1);
      ad[ix[i]] = acos(proxMin);         /* save distance in angular measure */
      }
   ticks_ll = clock() - ticks_0;

   n = 0;
   fprintf(stderr, "%s\n", names[ix[0]]);
   for (i = 1; i < nL; i++) {
      if (ix[i] == ix[i - 1]) continue;
      fprintf(stderr, "%s\n", names[ix[i]]);
      n++;
      }
   fprintf(stdout, "[Duration %d:%02d:%06.3f]\n\n", H0_Hours(ticks_ll), H0_Minutes(ticks_ll), H0_Seconds(ticks_ll));
/* for (i = 0; i < nL; i++) fprintf(stderr, "%s %8.1f\n", names[ix[i]], ERTHRAD * ad[ix[i]]); */

/* Times used by two loops: tests/sec., clock ticks, and relative to each other: */
   tC = tL = 0;
   if (CLOCKS_PER_SEC) {
      if (ticks_cdc) tC = (double)(nL * nA) / H0_Tic2Sec(ticks_cdc);
      if (ticks_ll) tL = (double)(nL * nA) / H0_Tic2Sec(ticks_ll);
      }

   fprintf(stdout, "Reporting:            clock-ticks tests/second  (relative)\n");
   fprintf(stdout, "-----------------------------------------------------------\n");
   fprintf(stdout, "Concise direction cosines: %6d   %7.0f   (1.000 %.3f)\n", ticks_cdc, tC, ticks_ll ? (double)ticks_cdc / (double)ticks_ll : -1.0);
   fprintf(stdout, "Latitude/longitude:        %6d   %7.0f   (%.3f 1.000)\n", ticks_ll, tL, ticks_cdc ? (double)ticks_ll / (double)ticks_cdc : -1.0);
   fprintf(stdout, "-----------------------------------------------------------\n");

   return(0);
   }
/* ========================================================================= */
/* Direct and inverse transformation from cosines to CDC as 4-byte integers: */
/* ------------------------------------------------------------------------- */
#define CDC_I4_SCALE 2147483640.0
#define CDC_I4_ROUND 1.25    /* to round (rather than truncate) service bits */

#define SET_0_LSB    ((hipp4_int)(~1))               /* & to set LSB to ...0 */
#define SET_1_LSB    ((hipp4_int)(1))                /* | to set LSB to ...1 */
#define SET_0_NLSB   ((hipp4_int)(~2))       /* & to set next to LSB to ...0 */
#define SET_1_NLSB   ((hipp4_int)(2))        /* | to set next to LSB to ...1 */
#define SET_00_LSB2  ((hipp4_int)(~3))          /* & to set 2 LSB's to ...00 */

void h0_Dcos3ToCdcH(const struct vct3 *vct, struct cdc_h *cdc) {
   double adi, adj, adk;
   adi = H1_fabs(vct->di);
   adj = H1_fabs(vct->dj);
   adk = H1_fabs(vct->dk);
   if ((adi >= adj) && (adi >= adk)) {                             /* drop i */
      cdc->u = (hipp4_int)(vct->dj * CDC_I4_SCALE + CDC_I4_ROUND) | SET_1_LSB;
      cdc->v = (hipp4_int)(vct->dk * CDC_I4_SCALE + CDC_I4_ROUND) | SET_1_LSB;
      if (vct->di < 0.0) cdc->u |= SET_1_NLSB;
      else cdc->u &= SET_0_NLSB;
      }
   else if ((adj >= adi) && (adj >= adk)) {                        /* drop j */
      cdc->u = (hipp4_int)(vct->di * CDC_I4_SCALE + CDC_I4_ROUND) & SET_0_LSB;
      cdc->v = (hipp4_int)(vct->dk * CDC_I4_SCALE + CDC_I4_ROUND) | SET_1_LSB;
      if (vct->dj < 0.0) cdc->u |= SET_1_NLSB;
      else cdc->u &= SET_0_NLSB;
      }
   else {                                                          /* drop k */
      cdc->u = (hipp4_int)(vct->di * CDC_I4_SCALE + CDC_I4_ROUND) & SET_0_LSB;
      cdc->v = (hipp4_int)(vct->dj * CDC_I4_SCALE + CDC_I4_ROUND) & SET_0_LSB;
      if (vct->dk < 0.0) cdc->u |= SET_1_NLSB;
      else cdc->u &= SET_0_NLSB;
      }
   return;
   }
/* ------------------------------------------------------------------------- */
void h0_CdcHToDcos3(const struct cdc_h *cdc, struct vct3 *vct) {
   double da, db, dc;
   da = ((double)(cdc->u & SET_00_LSB2)) / CDC_I4_SCALE;
   db = ((double)(cdc->v & SET_00_LSB2)) / CDC_I4_SCALE;
   dc = 1.0 - da * da - db * db;
   if (dc < FUZZCC) dc = 0.0;
   else {
      dc = H1_sqrt(dc);
      if (cdc->u & SET_1_NLSB) dc = -dc;
      }
   if (cdc->u & SET_1_LSB) {
      vct->di = dc;
      vct->dj = da;
      vct->dk = db;
      }
   else if (cdc->v & SET_1_LSB) {
      vct->di = da;
      vct->dj = dc;
      vct->dk = db;
      }
   else {
      vct->di = da;
      vct->dj = db;
      vct->dk = dc;
      }
   return;
   }
/* ========================================================================= */
/*  h1_Dcos3ToLatLong
 *
 *  Convert normalized vector components into angular (latitude and
 *  longitude) geographic coordinates. No data checking is performed.
 *
 *  Arguments:
 *
 *   pe:       Pointer to a vct3 structure, given spherical or
 *             spheroidal normal.
 *
 *   pa:       Pointer to an ltln structure, returned latitude and
 *             longitude, measurement in radians.
 *
 * ------------------------------------------------------------------------- */
void h1_Dcos3ToLatLong(const struct vct3 * pe, struct ltln * pa) {
   hf_type aux;
   aux = pe->di * pe->di + pe->dj * pe->dj;
   pa->lat = H1_atan2(pe->dk, H1_sqrt(aux));
   if (aux > FUZZC) {
      pa->lng = H1_atan2(pe->dj, pe->di);
      }
   else {
      pa->lng = 0.e0;
      }
   return;
   }
/* ========================================================================= */
/*  h1_LatLongToDcos3
 *
 *  Convert ellipsoidal or spherical coordinates from angular (latitude
 *  and longitude) into normalized vector components. Note that the
 *  function performs no data checking!
 *
 *  Arguments:
 *
 *   pa:       Pointer to an ltln structure, given latitude and longitude.
 *
 *   pe:       Pointer to a vct3 structure, returned spherical or
 *             ellipsoidal normal.
 * ------------------------------------------------------------------------- */
void h1_LatLongToDcos3(const struct ltln * pa, struct vct3 * pe) {
    ijk_type cosphi;
    if (pa->lat > PIHALF - FUZZA) {
       pe->di = 0.e0;
       pe->dj = 0.e0;
       pe->dk = 1.e0;
       }
    else if (pa->lat < FUZZA - PIHALF) {
       pe->di = 0.e0;
       pe->dj = 0.e0;
       pe->dk = -1.e0;
       }
    else {
       cosphi = H1_cos(pa->lat);
       pe->di = cosphi * H1_cos(pa->lng);
       pe->dj = cosphi * H1_sin(pa->lng);
       pe->dk = H1_sin(pa->lat);
       }
   return;
   }
/* ========================================================================= */
/*  h3_HipparchDistToArcApprox
 *
 *  Approximate and fast conversion of unit sphere square chord
 *  into arc distance. The value calculated by this function will
 *  always be greater than the true arc. Since the computation
 *  involves no transcendentals, it will be very fast.
 *
 *  Argument:
 *
 *       hp_dist:    Double, csq_dist type, given spherical chord square
 *                   on unit sphere.
 *
 *  Return Value:
 *
 *       Double, arc_dist type, spherical arc distance.
 *
 * ------------------------------------------------------------------------- */
#define KAS1  (1.0)
#define KAS3  (1.0 / 24.0)
#define KAS5  (3.0 / 640.0)
#define KAS7  (5.0 / 7168.0)
#define KAS9  (35.0 / 294912.0)
#define KAS11 (63.0 / 2883584.0)
#define KAS13 (231.0 / (13312.0 * 4096.0))
#define KAS15 (429.0 / (30720.0 * 16384.0))
#define KAS17 (6435.0 / (557056.0 * 65536.0))
#define KAS19 (12155.0 / (1245189.0 * 262144.0))

arc_dist h3_HipparchDistToArcApprox(csq_dist sq_chord) {
    hf_type chord;
    if (sq_chord < FUZZCC)
    return (0.0);
    chord = H1_sqrt(sq_chord);
    return (chord * (KAS1 + sq_chord
                  * (KAS3 + sq_chord
                  * (KAS5 + sq_chord
                  * (KAS7 + sq_chord
                  * (KAS9 + sq_chord
                  * (KAS11 + sq_chord
                  * (KAS13 + sq_chord
                  * (KAS15 + sq_chord
                  * (KAS17 + sq_chord
                  * (KAS19)))))))))));
   }
/* ========================================================================= */
/* Old time religion: simple great circle distance from angular latitude
   and longitude. This function represents only a partial solution: we
   return the cosine of the great circle angle, not the angle itself,
   and use the cosine as the proximity criterion. We thus save one
   transcendental evaluation in the inner loop.
 */
hf_type gcProx(struct ltln *p1, struct ltln *p2) {
   hf_type s1, s2, c1, c2, cld, ld;
   s1 = H1_sin(p1->lat);
   s2 = H1_sin(p2->lat);
   c1 = H1_cos(p1->lat);
   c2 = H1_cos(p2->lat);
   if (p2->lng > p1->lng) ld = (p2->lng - p1->lng);
   else ld = (p1->lng - p2->lng);
   if (ld < PI) cld = H1_cos(ld);
   else cld = H1_cos(PI + PI - ld);
   return(s1*s2 + c1*c2*cld);
   }
/* ========================================================================= */
