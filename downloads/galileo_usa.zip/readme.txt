galileo\readme.txt

Galileo Release 3.40 for Windows Notes.

INTRODUCTION

Galileo is the Hipparchus GIS programmer's "workbench" suite demonstrating
radical GIS concepts in a seamless global data domain.

Galileo is a scriptable, interactive Windows program suite that permits direct
manipulation of spatial application data using many of the functions of the
Hipparchus Libraries.  No formal programming is required to devise practical
solutions to seemingly complex GIS propositions.  Galileo is also an excellent
teaching aid for educators whose primary mission is to communicate the
fundamentals of GIS, cartography and/or metric survey computations.

Documentation for Galileo is co-located with this readme.txt as a set of
HTML documents: galileo.html, galile0.html, galileo1.html, namedcolors.html
and webcolors.html. The first of these, galileo.html, is the browser entry point.

Galileo programs, scripts and data are supplied for free in the hope that they
will be both instructive and useful, but without any warranty or guarantee
whatsoever, either explicit or implied.  In particular, the geographic data
supplied for demonstration purposes may contain residual errors or omissions.

You are invited to share this archive with others, either via computer media
or the Internet, provided only that Galileo is complete and unmodified and
that this readme.txt file has been included.

You are free to distribute (and, at your option, charge for) any additional
scripts or data that you may have developed yourself, illustrations generated
from Galileo, additional documentation, benchmark results and usage notes.


GALILEO NOTES

The principal executable, galileo.exe, is located in the runw32 sub-directory.
Initialization and several other files that are closely-coupled to Galileo are
contained in the same sub-directory. Otherwise, all the data and script files
used by Galileo are contained in two other sub-directories, galileo\data and
galileo\scripts. Another sub-directory galileo\temp may be used for transient
objects.

Galileo.exe was compiled and linked for Win32 environments using the Microsoft
Visual C/C++ compiler Version 6.0.  An associated ASCII text file named
galileo.gin is used to initialize various parameters during Galileo's
start-up.  You can modify this file with any text editor.

Galileo takes one or two optional command line parameters: the name of an
ASCII script file to be run at start-up and (optionally) the name of a label
in that script file.  If you have set up a desktop shortcut icon for Galileo,
you can start it with any script by dragging and dropping the icon for the
script onto the shortcut icon for Galileo. Alternatively, you could specify
Galileo as the default application for your *.gal files, then run any one of
them by double-clicking its icon.

Following the transfer of Galileo to your hard drive, we recommend that you
run the first general demonstration script, tour.gal, like this:

  ...\galileo\runw32\galileo tour

If Galileo was copied from a CD, be sure to write-enable the galileo.gin and
feedback.txt files located in the galileo sub-directory named runw32.

Other scripts you should be sure to run are: enterobjects, spatial101, space,
orbits, coordinates and voronoi. For the complete list of supplied scripts,
please consult the galileo sub-directory named scripts.

Windows Help is not provided with Galileo.  However, an extensive HTML file
set provides a complete guide to Galileo. This may be viewed on-line using any
Internet web browser, or printed for off-line study. The galileo.html file set
is co-located with galileo.exe in the runw32 sub-directory of galileo. It can be
initiated via the Galileo Help command.

A large amount of vector data has been included on the distribution CD. If you
have downloaded only an abridged version of Galileo, then you will not have
all of the data required to execute some of the scripts. Scripts requiring the
full complement of data will report any data missing.

Files ending with the extensions .pts, .lns and .rgn are ASCII basic
coordinate files, while files ending with the .gal extension are Galileo
script files.

Files ending with the .vix extension are binary copies of Voronoi index files.

Files ending with the .hbo extension are Hipparchus Binary Object files. These
are binary copies of internal Hipparchus memory objects created using the
EnterObject, ImportPset, ImportLset, ImportRset, Derive... or Trace...
commands. Galileo treats .hbo objects as memory-mapped files using
single-level nomenclature, just as if the files were present as memory
objects.  If not already present in the distribution, you can easily generate
such files by executing the appropriate Import... command. (Note that the
tour.gal and other supplied scripts conditionally Import... these files on
first use). Files ending with the .plr extension are binary data files created
off-line by Hipparchus Utilities.

Files ending with the .bmp, .jpg or .png extensions are either supplied in the
distribution or generated by the SaveBitMap command.

If you have received Galileo as part of a Hipparchus Developer's software
development kit (SDK), then you will have received the source code for
Galileo. You will also have received a quasi-make file named bldgalileo.bat
that may be consulted in establishing a re-compile procedure appropriate for
your specific development environment. We strongly recommend re-compiling
Galileo in the presence of a C/C++ source code browser.  The resulting
cross-references between source and executables will be of great value in
understanding the inner workings of Galileo, and their relationship to the
Hipparchus Library.  For diagnostic purposes, Galileo may be re-compiled with
a trace facility that writes to a trace file galileo.trc.  When you open this
file in a separate window, you will observe the steps followed by any given
command sequence.

Whether a Hipparchus Developer or not, explore and enjoy!

(signed by)

The Geodyssey Limited Development Team. Revised 2004/05/12.
