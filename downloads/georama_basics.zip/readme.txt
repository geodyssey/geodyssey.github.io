georama\readme.txt

Georama Release 3.40 for Windows Notes.

INTRODUCTION

Georama is the Hipparchus-based GPS-ready Atlas viewing suite demonstrating
radical GIS concepts in a seamless ellipsoidal planetary data domain.

Georama is an extensible, interactive Windows program suite that permits
viewing and plotting of Georama geographical scenes. Georama is also an
excellent teaching aid for educators whose primary mission is to communicate
the fundamentals of cartography (map-making), GIS and/or metric survey
computations.

Documentation for Georama is co-located with this readme.txt as a set of HTML
documents: georama.html, georama0.html, georama1.html, namedcolors.html and
webcolors.html. The first of these, georama.html, is the browser entry point.

Georama programs and data are supplied for free in the hope that they will be
both instructive and useful, but without any warranty or guarantee whatsoever,
either explicit or implied.  In particular, the geographic data supplied for
demonstration purposes may contain residual errors or omissions.

You are invited to share this archive with others, either via computer media
or the Internet, provided only that Georama is complete and unmodified and
that this readme.txt and associated license.txt files has been included.

You are free to distribute (and, at your option, charge for) any additional
atlas control files, scene control files or referenced data that you may have
developed yourself, illustrations generated from Georama, additional
documentation, benchmark results and/or usage notes.


GEORAMA NOTES

The principal executable, georama.exe, is located in the runw32 sub-directory.
Initialization and several other files that are closely-coupled to Georama are
contained in the same sub-directory. Otherwise, all the data and script files
used by Georama are contained in other Atlas-specific sub-directories, notably
georama\world and georama\new_zealand. Another sub-directory georama\temp may
be used for the storage of transient objects.

Georama.exe was compiled and linked for Win32 environments using the Microsoft
Visual C/C++ compiler Version 6.0.  A closely-associated ASCII text file named
georama.gin is used to initialize various parameters during Georama's
start-up. You can modify this file with any text editor.

Georama accepts one optional command line parameter: the name of an
Atlas directory to be opened at start-up.  If you have set up a desktop
shortcut icon for Georama, you can start it with any Atlas by dragging and
dropping the icon for the Atlas onto the shortcut icon for Georama.

Following the transfer of Georama to your hard drive, we recommend that you
run the first general demonstration script, tour.gal, like this:

  ...\georama\runw32\georama new_zealand

If Georama was copied from a CD, be sure to write-enable the georama.gin and
feedback.txt files located in the georama sub-directory named runw32.

Windows Help is not provided with Georama.  However, an extensive HTML file
set provides a complete guide to Georama. This may be viewed on-line using any
Internet web browser, or printed for off-line study. The georama.html file set
is co-located with georama.exe in the runw32 sub-directory of georama. It can
be initiated via the Georama Help command.

A large amount of vector data has been included on the distribution CD. If you
have downloaded only an abridged version of Georama, then you will not have
all of the data required to view all Atlases.

If you have received Georama as part of a Hipparchus Developer's software
development kit (SDK), then you will have received the source code for
Georama. You will also have received a quasi-make file named bldgeorama.bat
that may be consulted in establishing a re-compile procedure appropriate for
your specific development environment. We strongly recommend re-compiling
Georama in the presence of a C/C++ source code browser.  The resulting
cross-references between source and executables will be of great value in
understanding the inner workings of Georama, and their relationship to the
Hipparchus Library.

Whether a Hipparchus Developer or not, explore and enjoy!

(signed by)

The Geodyssey Limited Development Team. Revised 2004/05/12.
