/* Crumble 32-bit random ints returned by generator into one byte per call.   */
/* If called with non-0, seed it first; otherwise just the return next byte.  */
/* Note that we don't use srand()/rand() since want a sequence that can be    */
/* replicated in the decoder, regardless of the compiler and library used.    */
/* This function is assumed to be used only in single-thread applications.    */

#include "toolbox.h"

/* ========================================================================== */
unsigned char tb_RandByte(unsigned int seed) {
   static unsigned int rand32wa[TB_RAND32_WORK_ARRAY];
   static int ix;
   static union {
      unsigned int irand32;
      unsigned char randByte[4];
      } ru;
/* -------------------------------------------------------------------------- */
   if (seed) {
      rand32wa[0] = seed;                            /* seed random generator */
      ix = 3;                                /* as if all bytes were consumed */
      }
   ix++;
   if (ix%4 == 0) {
      ru.irand32 = tb_Rand32(rand32wa);        /* get a 32-bit random integer */
      ix = 1;
      }
   return(ru.randByte[ix - 1]);
   }
/* ========================================================================== */
