/* ========================================================================== */
/* The functions in this section are used to process command line arguments.

   It is assumed that a command line consists of file names (typically two,
   one input and one output) and of several "flags". The flags are introduced
   by a dash and a single case sensitive letter, followed by an optional "="
   sign, followed by an optional character string value. Command line strings
   which do not start with a dash are assumed to be file names. They are
   returned to the application in the order in which they appear on the command
   line. Examples of command line arguments (excluding the program name which)
   invoked the application) processed by these two functions are as follows:

   infile.bmp -X=xyz letter.txt
   -c \home\doej\story.doc story.wpd
   /doej/testset.waz -d=2 -r=23 outset.waz

/* (Both functions are assumed to be used in a single-thread program only).   */
/* ========================================================================== */
#include "toolbox.h"

/* Return the pointer of the next non-flag command line string, NULL if none. */
char *tb_CLineFileName(int argc,              /* as found on the command line */
                       char **argv) {         /* as found on the command line */
   char *fnm = NULL;
   static int next_cls = 1;      /* sigle line use (once per program) */
/* -------------------------------------------------------------------------- */
   while (next_cls < argc) {
      fnm = argv[next_cls];
      next_cls++;
      if (*fnm == '-') continue;
      return(fnm);
      }
   return(NULL);
   }
/* ========================================================================== */
/* Return next option character and option value found on the command line.   */
int tb_CLineOption(int argc,                  /* as found on the command line */
                   char **argv,               /* as found on the command line */
                   char **optval) {                  /* returned option value */
   static int next_cls = 1;              /* sigle line use (once per program) */
   static char nullchar = '\0';      /* so invoker gets null-string, not NULL */
/* -------------------------------------------------------------------------- */
   int ifl, ivl;
   char *pa;
   ifl = ivl = 0;
   if (optval) *optval = &nullchar;
   while (next_cls < argc) {
      pa = argv[next_cls++];
      if (*pa == '-') {                  /* Burp now requires Unix style flag */
         ifl = *(pa + 1);
         if (ifl) ivl = *(pa + 2);
         if (ivl == '=') {                              /* style is /f=xyz... */
            ivl = *(pa + 3);
            if (optval && ivl) *optval = pa + 3;
            }
         else {                                          /* style is /fxyz... */
            if (optval && ivl) *optval = pa + 2;
            }
         return(ifl);
         }
      }
   return(-1);
   }
/* ========================================================================== */
