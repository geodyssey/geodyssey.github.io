/* Encode/decode binary data as ascii characters. Three binary
   bytes require four ascii characters. It is assumed that the
   invoker keeps track of block length, and that the byte count
   of binary input data will be evenly divisible by 3, and that
   acsii character input data will be evenly divisible by 4.

   64 Ascii characters used for encoding are numerals, upper and
   lover case 26 alpha characters and left/right curly braces.

   Note that both functions are returning the same data on both
   little and big endian platforms.

 */

const static unsigned char c64[] =
 "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz{}";

const static unsigned int i64[] = {
    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
    0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
    0,  1,  2,  3,  4,  5,  6,  7,  8,  9,  0,  0,  0,  0,  0,  0,
    0, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24,
   25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35,  0,  0,  0,  0,  0,
    0, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50,
   51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62,  0, 63,  0,  0};

#include "toolbox.h"

void tb_Encode64(const unsigned char *in,         /* input data block */
                int m,            /* length of the above, must be 3*n */
                unsigned char *out) {     /* returned data block, 4*n */
   int i, j, k;
/* ------------------------------------------------------------------ */
   j = 0;
   for (i = 0; i < m; i += 3) {
      out[j++] = c64[in[i] % 64];
      k = (in[i] / 64);
      out[j++] = c64[in[i + 1] % 64];
      k += 4 * (in[i + 1] / 64);
      out[j++] = c64[in[i + 2] % 64];
      k += 16 * (in[i + 2] / 64);
      out[j++] = c64[k];
      }
   return;
   }
/* ================================================================== */
void tb_Decode64(const unsigned char *in,         /* input data block */
                 int m,           /* length of the above, must be 4*n */
                 unsigned char *out) {      /* output data block, 3*n */
   int i, ii, j, k, kk, l;
/* ------------------------------------------------------------------ */
   j = 0;
   for (i = 0; i < m; i += 4) {
      k = i64[in[i + 3]];
      for (ii = 0; ii < 3; ii++) {
         l = i64[in[i + ii]];
         kk = k % 4;
         k /= 4;
         out[j++] = (unsigned char)(l + (64 * kk));
         }
      }
   return;
   }
/* ================================================================== */
