/* Functions to provide byte order checking and reversing at run-time.
   We only handle two configurations: comonly called Motorola (big) and
   Intel (little endian). (Motorola stores most significant byte first).

   Endian-dependent processing is commonly controlled by compile time
   facilities; for the ease of code movement, and at a slight expense in
   processing time and code size it can be done at run time as follows:
 */

#include "toolbox.h"

union endian32 {
   unsigned int i;
   unsigned char c[4];
   };
union endian16 {
   unsigned short i;
   unsigned char c[2];
   };
/* ===================================================================== */
int tb_IsBigEndian(void) {
   union endian16 et;
/* --------------------------------------------------------------------- */
   et.i = 1;
   et.c[0] = '\0';
   return((int)(et.i));
   }
/* ===================================================================== */
void tb_ReverseWords16(unsigned short *t,             /* array of shorts */
                       int n) {                          /* count of t's */
   union endian16 *e16;
   unsigned char c;
/* --------------------------------------------------------------------- */
   while (n--) {
      e16 = (union endian16 *)(t + n);
      c = e16->c[0];
      e16->c[0] = e16->c[1];
      e16->c[1] = c;
      }
   }
/* ===================================================================== */
void tb_ReverseWords32(unsigned int *t,                 /* array of ints */
                       int n) {                          /* count of t's */
   union endian32 *e32;
   unsigned char c;
/* --------------------------------------------------------------------- */
   while (n--) {
      e32 = (union endian32 *)(t + n);
      c = e32->c[0];
      e32->c[0] = e32->c[3];
      e32->c[3] = c;
      c = e32->c[1];
      e32->c[1] = e32->c[2];
      e32->c[2] = c;
      }
   }
/* ===================================================================== */
/* similar to the above, but buffer need not be aligned... */
void tb_ReverseBytes32(unsigned char *buf,     /* must be divisible by 4 */
                       int n) {                 /* how many in the above */
   int i;
   unsigned char uc;
/* --------------------------------------------------------------------- */
   for (i = 0; i < n; i += 4) {
      uc = buf[i];
      buf[i] = buf[i+3];
      buf[i+3] = uc;
      uc = buf[i+1];
      buf[i+1] = buf[i+2];
      buf[i+2] = uc;
      }
   }
/* ===================================================================== */
