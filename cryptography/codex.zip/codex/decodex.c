/* decodex.c - Decode64-decrypt-decompress. (Sibling of encodex.c)

   This program demonstrates the method used by notex and similar
   programs to decrypt text. The program is not a complete cryptographic
   application: in particular, note the absence of any clean-up in case
   of abnormal termination and a rather unsecure method of key-entry.

   See the preamble of encodex.c for a complete discussion of the text
   format and C language code.

   Programmer: Hrvoje Lukatela, 2002
 */

#include <string.h>
#include <stdio.h>

#include "toolbox.h"

#define KEY_MIN                 8                       /* minimum key lenght */
#define KEY_MAX                16                       /* maximum key length */
#define PASS_PHRASE_MAX       100                /* maximum passphrase length */

#define CRYPT_BLOCK_INTS        2
#define CRYPT_BLOCK_CHARS       8

#define BASE64_BIN_LENGTH      48
#define BASE64_ENCODED_LENGTH  64

static void usage(char *, char *);
static unsigned char *nextData64Line(const unsigned char *, int, int *);

int main(int argc, char **argv) {

   char   inFn[FILENAME_MAX + 2];
   FILE  *inFp;
   char   outFn[FILENAME_MAX + 2];
   FILE  *outFp;
   char   keyStr[PASS_PHRASE_MAX + 2];
   unsigned char key[KEY_MAX];

   unsigned char *padA;
   unsigned char *padB;
   unsigned int cryptoPad[TB_BFPAD_SIZE];                     /* Blowfish pad */

   int    n, padSize;

   int    i, ixIn, ixOut, iBigEndian;

   unsigned int fr[2];                                 /* feedback "register" */
   unsigned int cryptBlock[2];                           /* one we operate on */
   unsigned int prevBlock[2];                            /* one we operate on */
   unsigned char binLine[BASE64_BIN_LENGTH];

   int    inTextLength, decompressedTextLength, compressedTextLength;
   int    cipherTextLength, plainTextLength;
   unsigned int crc32in, crc32check;

   unsigned char *puc;

   int    optch;
   char  *optval;
   char  *progfullname;
   char  *progname;
   char  *pa;
/* -------------------------------------------------------------------------- */
   progfullname = (char *)malloc(strlen(argv[0]) + 1);
   strcpy(progfullname, argv[0]);
   fprintf(stderr, "%s: decrypt text in textec format.\n", progfullname);
   pa = strrchr(progfullname, TB_SUFFIX_SEPARATOR);
   if (pa) *pa = '\0';
   pa = strrchr(progfullname, TB_DIR_SEPARATOR);
   if (pa) progname = pa + 1;
   else progname = progfullname;
   *keyStr = '\0';
   iBigEndian = tb_IsBigEndian();

   if (argc < 2) usage(progname, NULL);

   while ((optch = tb_CLineOption(argc, argv, &optval)) != -1) {
      switch (optch) {
         case 'h': case '?': usage(progname, NULL); break;
         case 'k': strncpy(keyStr, optval, PASS_PHRASE_MAX); break;
         default: usage(progname, "unexpected option");
         }
      }

   if (*keyStr == '\0') tb_ErrorExit(progname, NULL, NULL, __LINE__, "No key given (-k=...).\n");
   if (strlen(keyStr) < KEY_MIN) tb_ErrorExit(progname, NULL, NULL, __LINE__, "Key or passphrase (%s) must be at least %d characters long.\n", keyStr, KEY_MIN);

   pa = tb_CLineFileName(argc, argv);                      /* input file name */
   if (pa == NULL) tb_ErrorExit(progname, NULL, NULL, __LINE__, "No input file name given\n");
   strcpy(inFn, pa);
   inFp = fopen(inFn, "rb");
   if (inFp == NULL) tb_ErrorExit(progname, NULL, NULL, __LINE__, "Input file [%s] open error\n", inFn);

   fseek(inFp, 0, SEEK_END);
   inTextLength = ftell(inFp);
   fseek(inFp, 0, SEEK_SET);
   if (inTextLength == 0) tb_ErrorExit(progname, NULL, NULL, __LINE__, "Zero-length file [%s]\n", inFn);

   pa = tb_CLineFileName(argc, argv);                  /* output file name... */
   if (pa == NULL) {
      strcpy(outFn, "standard output");
      outFp = stdout;
      }
   else {
      strcpy(outFn, pa);
/*    outFp = fopen(outFn, TB_TEXT_WRITE_OPEN); */
      outFp = fopen(outFn, "wb");
      }
   if (outFp == NULL) tb_ErrorExit(progname, NULL, NULL, __LINE__, "Can't open %s for writing\n", outFn);

/* Text will be ping-ponged between two "workpads" - A and B */
   padSize = 8 * inTextLength + 1024;             /* max decompression factor */
   padA = (unsigned char *)malloc(padSize + 2);
   padB = (unsigned char *)malloc(padSize + 2);
   if ((padA == NULL) || (padB == NULL)) tb_ErrorExit(progname, NULL, NULL, __LINE__, "Memory (%d) allocation error.\n", padSize + padSize);

/* Step 0: initialize Blowfish */
   n = strlen(keyStr);                   /* did we get a key or a passphrase? */
   if (n > KEY_MAX) {
      tb_HashBytes((unsigned char *)keyStr, n, key);
      n = KEY_MAX;
      }
   else memcpy(key, keyStr, n);

   i = tb_BlowfishInitPad(cryptoPad, key, n);
   if (i) tb_ErrorExit(progname, NULL, NULL, __LINE__, "Blowfish initialization error %d.\n", i);

   memset(keyStr, '\0', PASS_PHRASE_MAX);             /* done with passphrase */
   memset(key, '\0', KEY_MAX);                                  /* and/or key */

   fprintf(stderr, "Step 0: Reading %d bytes from %s\n", inTextLength, inFn);
/* -------------------------------------------------------------------------- */
   if ((int)fread(padA, 1, inTextLength, inFp) < inTextLength) tb_ErrorExit(progname, NULL, NULL, __LINE__, "Input file [%s] read error.\n", inFn);
   fclose(inFp);

   fprintf(stderr, "Step 1: Decoding64 raw input %d bytes\n", inTextLength);
/* -------------------------------------------------------------------------- */
   crc32in = cipherTextLength = ixIn = ixOut = 0;
   while (puc = nextData64Line(padA, inTextLength, &ixIn)) {
/*    fprintf(stderr, "%c...%c\n", puc[0], puc[BASE64_ENCODED_LENGTH - 1]);*/
      tb_Decode64(puc, BASE64_ENCODED_LENGTH, binLine);          /* decode it */
      if (ixOut == 0) {                     /* extract values from first line */
         memcpy(&crc32in, binLine, 4);               /* first 4 bytes are crc */
         if (iBigEndian) tb_ReverseWords32(&crc32in, 1);
         memcpy(&cipherTextLength, binLine + 4, 4); /* next 4 bytes are count */
         if (iBigEndian) tb_ReverseWords32((unsigned int *)&cipherTextLength, 1);
         memcpy(padB, binLine + 8, BASE64_BIN_LENGTH - 8);    /* rest is data */
         ixOut = BASE64_BIN_LENGTH - 8;
         }
      else {
         memcpy(padB + ixOut, binLine, BASE64_BIN_LENGTH);
         ixOut += BASE64_BIN_LENGTH;
         }
      }

/* First check size for something sensible */
   if ((cipherTextLength < CRYPT_BLOCK_CHARS) || (cipherTextLength > (ixOut))) tb_ErrorExit(progname, NULL, NULL, __LINE__, "Bad decode64 length %d (%d - %d)\n", cipherTextLength, 0, ixOut);

/* Next check the CRC - this tells us we have picked up all encoded lines.    */
   crc32check = tb_Crc32(0, padB, cipherTextLength);
   if (crc32check != crc32in) tb_ErrorExit(progname, NULL, NULL, __LINE__, "Invalid ciphertext CRC - check: %08x in: %08x.\n", crc32check, crc32in);

   fprintf(stderr, "Step 2: Decrypting %d bytes\n", cipherTextLength);
/* ------------------------------------------------------------------- */
   memcpy(fr, padB, CRYPT_BLOCK_CHARS);                             /* get IV */
   for (ixIn = CRYPT_BLOCK_CHARS, ixOut = 0;
       (ixIn + CRYPT_BLOCK_CHARS) <= cipherTextLength;
        ixIn += CRYPT_BLOCK_CHARS, ixOut += CRYPT_BLOCK_CHARS) {

      memcpy(cryptBlock, padB + ixIn, CRYPT_BLOCK_CHARS);   /* get next block */
      if (iBigEndian) tb_ReverseWords32(cryptBlock, CRYPT_BLOCK_INTS);
      tb_BlowfishDeCrypt(cryptoPad, cryptBlock, prevBlock);        /* decrypt */
      if (iBigEndian) tb_ReverseWords32(cryptBlock, CRYPT_BLOCK_INTS);
      if (iBigEndian) tb_ReverseWords32(prevBlock, CRYPT_BLOCK_INTS);
      prevBlock[0] ^= fr[0];
      prevBlock[1] ^= fr[1];
      memcpy(fr, cryptBlock, CRYPT_BLOCK_CHARS);
      memcpy(padB + ixOut, prevBlock, CRYPT_BLOCK_CHARS);
      }

   plainTextLength = ixOut;

   i = cipherTextLength - ixIn;
   if (i) {                                         /* last block was partial */
      plainTextLength = plainTextLength - CRYPT_BLOCK_CHARS + i;
      }

   memset(cryptoPad, '\0', TB_BFPAD_SIZE * sizeof(int));  /* done with BF pad */
   memset(fr, '\0', CRYPT_BLOCK_CHARS);
   memset(cryptBlock, '\0', CRYPT_BLOCK_CHARS);
   memset(prevBlock, '\0', CRYPT_BLOCK_CHARS);

   fprintf(stderr, "Step 3: Decompressing %d bytes\n", plainTextLength);
/* --------------------------------------------------------------------- */
   i = plainTextLength - 1;
/* fprintf(stderr, "Compress flag %d stored at %d.\n", padB[i], i);*/
   compressedTextLength = plainTextLength - 1;
   if (padB[i]%2) {                                         /* not compressed */
      memcpy(padA, padB, compressedTextLength);
      decompressedTextLength = compressedTextLength;
/*    fprintf(stderr, "        Text was not compressed.\n");*/
      }
   else {                                              /* text was compressed */
/*    fprintf(stderr, "        About to decompress (%d).\n", compressedTextLength);*/
      decompressedTextLength = tb_DecompressText(padB, compressedTextLength, padA, padSize - TB_COMPRESS_TEXT_EXTRA_CHARS);
/*    fprintf(stderr, "        Decompressed to (%d).\n", decompressedTextLength);*/
      if (decompressedTextLength == TB_DECOMPRESS_UNABLE) tb_ErrorExit(progname, NULL, NULL, __LINE__, "Unexpected error - decompression. (Key?)\n");
      }

   memset(padB, '\0', padSize);
   free(padB);

   fprintf(stderr, "Step 4: Writing %d bytes to %s\n", decompressedTextLength, outFn);
/* ----------------------------------------------------------------------------------- */
   if ((int)fwrite(padA, 1, decompressedTextLength, outFp) < decompressedTextLength) tb_ErrorExit(progname, NULL, NULL, __LINE__, "Output file [%s] write error.\n", outFn);
   fclose(outFp);

   memset(padA, '\0', padSize);
   free(padA);

   return(0);
   }
/* ========================================================================== */
static unsigned char *nextData64Line(const unsigned char *workPad,   /* input */
                                     int lngth,         /* total of the above */
                                     int *ix) {   /* next parse char in above */
   int n;
   int ch;
   int i;
/* -------------------------------------------------------------------------- */
   n = 0;                                  /* count of consecutive code chars */
   i = *ix;
/* fprintf(stderr, "parse from %d of %d\n", i, lngth);*/
   while (i < lngth) {
      ch = workPad[i++];                                    /* next character */
      if (((ch >= '0') && (ch <= '9'))    /* is it one of the encoding chars? */
       || ((ch >= 'A') && (ch <= 'Z'))
       || ((ch >= 'a') && (ch <= 'z'))
       || (ch == '{')
       || (ch == '}')) {
         n++;
         }
      else if ((ch == ' ')
       || (ch == '\r')
       || (ch == '\n')) {                               /* possible line end? */
/*       fprintf(stderr, "Terminating char %d i:%d n:%d\n", ch, i, n);*/
/*       Do we have an uninterrupted sequence of at least 64 code characters. */
         if (n >= BASE64_ENCODED_LENGTH) {
            *ix = i;
            return((unsigned char *)(workPad + i - BASE64_ENCODED_LENGTH - 1));
            }
         n = 0;
         }
      else {
/*       fprintf(stderr, "Unexpected char %d i:%d n:%d\n", ch, i, n);*/
         n = 0;
         }
      }
/* Do we have a line with no ending newline character? */
   if (n >= BASE64_ENCODED_LENGTH) {
      *ix = i = lngth;
/*    fprintf(stderr, "Returning last buffer at %d\n", i - BASE64_ENCODED_LENGTH);*/
      return((unsigned char *)(workPad + i - BASE64_ENCODED_LENGTH));
      }

   *ix = lngth;
   return(NULL);
   }
/* ========================================================================== */
static void usage(char *progname, char *msg) {
   if (msg) fprintf (stderr, "Error: %s\n", msg);
   fprintf (stderr, "Usage: %s [options] infile [options] outfile\n", progname);
   fprintf (stderr, "  infile:  name of input file\n");
   fprintf (stderr, "Options:\n");
   fprintf (stderr, "  -h   to print this usage help and exit\n");
   fprintf (stderr, "  -k=\"key\" key or passphrase\n");
   exit(1);
   }
/* ========================================================================== */
#include "cline.c"
#include "errexit.c"
#include "endian.c"
#include "md5.c"
#include "blowfish.c"
#include "compr.c"
#include "base64.c"
#include "crc32.c"
#include "rand32.c"
#include "randbyte.c"
/* ========================================================================== */
