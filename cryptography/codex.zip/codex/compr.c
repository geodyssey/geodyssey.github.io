/* Simple in-memory compression and decompression, usefull for ascii text.
   Adapted from a public domain source. 32-bit ints assumed throughout.

   Notes:

   Both functions return the size of the target memory filled with
   generated (compressed or decompressed) data. If the input data
   could not be compressed tb_CompressText() will return a flag value
   TB_COMPRESS_UNABLE. (If this was the case, the returned data values
   vill be undefined - tb_UncompressText() must not be invoked to
   operate on such data).

   Compression target memory must be (at least)
   TB_COMPRESS_TEXT_EXTRA_CHARS longer than source data block.
   However, returned compressed memory length (in the case the data
   was successfully compressed) will be no longer than the source data.

   Decompression target memory will never exceed eight times that of the
   compressed data block. It is however safe to provide a block of the
   same size as that of the data before compression, if known. If this
   value is not known, and a tighter memory limit than eight times size
   of the compressed text is required - or the decompression might be
   invoked on corrupt compressed data, the invoker can optionally set
   a memory-checking limit by providing a non-0 value for the last
   parameter of the decompression function. If a process reaches this
   limit it will exit and signal failure. Note that the actual length of
   the decompression memory must (similar to the compression) be at least
   TB_COMPRESS_TEXT_EXTRA_CHARS longer than the indicated limit. This
   facility is provided to deal with a run-away decompression condition
   caused by the corrupt "compressed" data. As expected, checking will
   impact the speed of decompression process.

   Input and output memory blocks must not ovelap
   (i.e. no in-situ compression or decompression can be performed).

   Byte-order sensitive elements of the compressed data are arranged
   in little-endian byte order. (This requires functions in endian.c)
 */

#include "toolbox.h"

#define COMPR_PP(p1, p2) (*(p1)++ != *(p2)++)          /* Compare step. */
#define COMPR_MAX_ITEMS  16   /* Max. number of bytes in expanded item. */
/* ==================================================================== */
int tb_CompressText(const unsigned char *memSource,      /* source data */
                    int memSourceLngth,              /* length of above */
                    unsigned char *memTarget) {        /* target memory */
   int accum = 0;
   int nAccum = 0;
   unsigned char *pAccum;
   const unsigned char *pSourceA = memSource;
   const unsigned char *pSourceB = memSource + memSourceLngth;
   unsigned char *pTargetA = memTarget;
   unsigned char *pTargetB = memTarget + memSourceLngth;
   const unsigned char *pSource1 = pSourceB - COMPR_MAX_ITEMS;
   const unsigned char *pSource16 = pSourceB - 16 * COMPR_MAX_ITEMS;
   const unsigned char *hTable[4096];
/* -------------------------------------------------------------------- */
   pAccum = pTargetA;
   pTargetA += 2;

   for (;;) {
      const unsigned char *pa;
      const unsigned char *pb;
      int iters = 16, len, ix;
      unsigned int nx;
      if (pTargetA > pTargetB) return(TB_COMPRESS_UNABLE);
      if (pSourceA > pSource16) {
         iters = 1;
         if (pSourceA > pSource1) {
            if (pSourceA == pSourceB) break;
            goto literal;
            }
         }

      do {
         ix = ((40543 * ((((pSourceA[0] << 4) ^ pSourceA[1]) << 4) ^ pSourceA[2])) >> 4) & 0xFFF;
         pa = hTable[ix];
         hTable[ix] = pb = pSourceA;
         nx = pb - pa;
         if (nx > 4095 || pa < memSource || nx == 0 || COMPR_PP(pa, pb) || COMPR_PP(pa, pb) || COMPR_PP(pa, pb)) {
            literal: *pTargetA++ = *pSourceA++;
            accum >>= 1;
            nAccum++;
            }
         else {
            COMPR_PP(pa, pb) || COMPR_PP(pa, pb) || COMPR_PP(pa, pb) ||
            COMPR_PP(pa, pb) || COMPR_PP(pa, pb) || COMPR_PP(pa, pb) ||
            COMPR_PP(pa, pb) || COMPR_PP(pa, pb) || COMPR_PP(pa, pb) ||
            COMPR_PP(pa, pb) || COMPR_PP(pa, pb) || COMPR_PP(pa, pb) ||
            COMPR_PP(pa, pb) || pb++;
            len = pb - pSourceA - 1;
            *pTargetA++ = (unsigned char)(((nx & 0xF00) >> 4) + (len - 1));
            *pTargetA++ = (unsigned char)(nx & 0xFF);
            pSourceA += len;
            accum = (accum >> 1) | 0x8000;
            nAccum++;
            }
         } while (--iters);

      if (nAccum == 16) {
         *pAccum = (unsigned char)(accum & 0xFF);
         *(pAccum + 1) = (unsigned char)(accum >> 8);
         pAccum = pTargetA;
         pTargetA += 2;
         accum = nAccum = 0;
         }
      }

   accum >>= 16 - nAccum;
   *pAccum++ = (unsigned char)(accum & 0xFF);
   *pAccum++ = (unsigned char)(accum >> 8);
   if (pAccum == pTargetA) pTargetA -= 2;
   return(pTargetA - memTarget);
   }
/* ==================================================================== */
int tb_DecompressText(const unsigned char *memSource,    /* source data */
                      int memSourceLngth,            /* length of above */
                      unsigned char *memTarget,        /* target memory */
                      int memTargetLngth) {     /* 0 or length of above */
   int accum = 0;
   int nAccum = 0;
   const unsigned char *pSourceA = memSource;
   const unsigned char *pSourceZ = memSource + memSourceLngth;
   unsigned char *pTarget = memTarget;
   unsigned char *pTargetZ;
/* -------------------------------------------------------------------- */
/* Has output length checking been requested (by a non0 target length)? */
   if (memTargetLngth) pTargetZ = memTarget + memTargetLngth;
   else pTargetZ = NULL;                          /* damn the torpedoes */

   while (pSourceA < pSourceZ) {
      if ((pTargetZ) && (pTarget > pTargetZ)) return(TB_DECOMPRESS_UNABLE);
      if (nAccum == 0) {
         accum = *pSourceA++;
         accum |= (*pSourceA++) << 8;
         nAccum = 16;
         }
      if (accum & 1) {
         int nx, len;
         unsigned char *pa;
         nx = (*pSourceA & 0xF0) << 4;
         len = 1 + (*pSourceA++ & 0xF);
         nx += *pSourceA++ & 0xFF;
         pa = pTarget - nx;
         if ((pTargetZ) && (pa < memTarget)) return(TB_DECOMPRESS_UNABLE);
         while (len--) *pTarget++ = *pa++;
         }
      else *pTarget++ = *pSourceA++;
      accum >>= 1;
      nAccum--;
      }
   return(pTarget - memTarget);
   }
/* ==================================================================== */
