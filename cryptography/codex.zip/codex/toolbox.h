/* "ToolBox" [tb_...()] functions, covering the following:

   Command line file name and argument retrieval.
   Console mode error report/abort.
   Run-time endian testing and adjusting.
   CRC16, CRC32 computation.
   Rundom number generation.
   MD5 hash.
   Entropy procurement.
   Binary/character encoding and decoding.
   In-memory text data compression and decompression.

   All of these functions assume short int to be 16-bits, int to be 32-bits.
*/
#ifndef TOOLBOX_INCLUDED
#define TOOLBOX_INCLUDED

#include <stddef.h>
#include <stdlib.h>

typedef unsigned int tbWord32;                                /* 32-bit word! */

#if defined _POSIX_SOURCE
#define TB_TEXT_READ_OPEN    "r"
#define TB_TEXT_WRITE_OPEN   "w"
#define TB_TEXT_APPEND_OPEN  "a"
#define TB_DIR_SEPARATOR     '/'
#define TB_SUFFIX_SEPARATOR  '.'
#define TB_LIST_SEPARATOR    ':'
/* Following is required for file access() and line endings default */
#include <unistd.h>
#define DEFAULT_TEXT_LINE_ENDING 1

#elif defined _WIN32
#define TB_TEXT_READ_OPEN    "rt"
#define TB_TEXT_WRITE_OPEN   "wt"
#define TB_TEXT_APPEND_OPEN  "at"
#define TB_DRIVE_SEPARATOR   ':'
#define TB_DIR_SEPARATOR     '\\'
#define TB_SUFFIX_SEPARATOR  '.'
#define TB_LIST_SEPARATOR    ';'
/* see above - file access() and line endings */
#include <io.h>
#define DEFAULT_TEXT_LINE_ENDING 2

#else
#error "toolbox.h: no platform/version define given"
#endif

int            tb_CLineOption(int, char **, char **);
char          *tb_CLineFileName(int, char **);

void           tb_ErrorExit(char *, void (*cleanup)(void *), void *, int, char *, ...);

int            tb_IsBigEndian();          /* 0 is little, non 0 is big endian */
void           tb_ReverseWords16(unsigned short *, int);
void           tb_ReverseWords32(unsigned int *, int);
void           tb_ReverseBytes32(unsigned char *, int);

unsigned short tb_Crc16(unsigned short, unsigned char *, int);
unsigned int   tb_Crc32(unsigned int, unsigned char *, int);

#define        TB_RAND32_WORK_ARRAY   22                   /* Work array size */
unsigned int   tb_Rand32(unsigned int *);
unsigned char  tb_RandByte(unsigned int);

#define        TB_HASH_SIZE           16
int            tb_HashBytes(const unsigned char *, int, unsigned char *);

#define        TB_BFPAD_SIZE        1042          /* unsigned 32-bit integers */
#define        TB_BFKEY_MAX           56                        /* characters */
#define        TB_BFBLOCK_LENGTH       2                 /* unsigned integers */
int            tb_BlowfishInitPad(unsigned int *, const unsigned char *, int);
int            tb_BlowfishTestPad(const unsigned int *);
void           tb_BlowfishEnCrypt(const unsigned int *, const unsigned int *, unsigned int *);
void           tb_BlowfishDeCrypt(const unsigned int *, const unsigned int *, unsigned int *);

#define        TB_SWAMP_SIZE        1020
unsigned char *tb_EntropyInit();
int            tb_EntropyAddInt(unsigned int);
int            tb_EntropyAddChars(unsigned char *, int);
int            tb_EntropyGet(unsigned char *);

void           tb_Encode64(const unsigned char *, int, unsigned char *);
void           tb_Decode64(const unsigned char *, int, unsigned char *);

#define        TB_COMPRESS_TEXT_EXTRA_CHARS 256
#define        TB_COMPRESS_UNABLE            -1
#define        TB_DECOMPRESS_UNABLE          -1
int            tb_CompressText(const unsigned char *, int, unsigned char *);
int            tb_DecompressText(const unsigned char *, int, unsigned char *, int);

#endif
