#include <stdarg.h>
#include <stdio.h>

void cleanup(void *);

#include "toolbox.h"
/* ========================================================================== */
void tb_ErrorExit(char *progname,           /* Character string, program name */
                  void (*cleanup)(void *),        /* cleanup function or NULL */
                  void *cleanupData,                  /* cleanup data or NULL */
                  int line,                    /* integer, source line number */
                  char *fmt,                      /* character string, format */
                  ...) {                       /* variable list, message data */
/* ========================================================================== */
   va_list p_arg;
   va_start(p_arg, fmt);
   fprintf(stderr, "Error %s(%d): ", progname, line);
   vfprintf(stderr, fmt, p_arg);
   va_end(p_arg);
/* Optionally, the invoker might supply a function to perform cleanup... */
   if (cleanup) (*cleanup)(cleanupData);
   exit(1);
   }
/* ========================================================================== */
