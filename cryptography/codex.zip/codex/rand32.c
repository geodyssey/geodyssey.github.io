/* Code derived from a source found on the 'net, origin unknown.

   A function to return 32 preudorandom bits. The argument is a
   pointer to a thread-specific 32-bit integer work array of
   RAND32_WORK_ARRAY elements. The first element MUST be initialized
   to a non-0 seed value before the first invocation of the function,
   and, optionally, re-initialized each time a different seed-defined
   deterministic sequence is required. The code assumes 32-bit integers.
 */

#include "toolbox.h"

#define ROTATE(x, b) x = (((x) << (b)) | ((x) >> (32 - (b))))

unsigned int tb_Rand32(unsigned int *rw) {
   unsigned int seed;
   register unsigned int y, x = 0, sum = 0;
   int rounds = 3;
/* rw[0] : seed
   rw[1] : random_pos
   rw[2] : random_in[0]
     ... : ...
   rw[5] : random_in[3]
   rw[6] : random_t[0]
     ... : ...
   rw[21]: random_t[15]
 */
   if (*rw) {                                /* new seed walue */
      seed = *rw;
      memset(rw, '\0', TB_RAND32_WORK_ARRAY * sizeof(unsigned int));
      rw[4] = seed;
      rw[5] = 0x59697636;
      }

   if (rw[1]) return(rw[6 + --(rw[1])]);

   y = rw[2]; rw[7]  = rw[8]  = rw[9]  = 0; rw[6]  = y;
   y = rw[3]; rw[11] = rw[12] = rw[13] = 0; rw[10] = y;
   y = rw[4]; rw[15] = rw[16] = rw[17] = 0; rw[14] = y;
   y = rw[5]; rw[19] = rw[20] = rw[21] = 0; rw[18] = y;

   do {
      sum += 0x9e3779b9; y = x; y += sum;
      ROTATE(x,5);  x ^= y; y = rw[6];  x += y; y = sum; rw[6]  = x; y += x;
      ROTATE(x,7);  x ^= y; y = rw[7];  x += y; y = sum; rw[7]  = x; y += x;
      ROTATE(x,9);  x ^= y; y = rw[8];  x += y; y = sum; rw[8]  = x; y += x;
      ROTATE(x,13); x ^= y; y = rw[9];  x += y; y = sum; rw[9]  = x; y += x;
      ROTATE(x,5);  x ^= y; y = rw[10]; x += y; y = sum; rw[10] = x; y += x;
      ROTATE(x,7);  x ^= y; y = rw[11]; x += y; y = sum; rw[11] = x; y += x;
      ROTATE(x,9);  x ^= y; y = rw[12]; x += y; y = sum; rw[12] = x; y += x;
      ROTATE(x,13); x ^= y; y = rw[13]; x += y; y = sum; rw[13] = x; y += x;
      ROTATE(x,5);  x ^= y; y = rw[14]; x += y; y = sum; rw[14] = x; y += x;
      ROTATE(x,7);  x ^= y; y = rw[15]; x += y; y = sum; rw[15] = x; y += x;
      ROTATE(x,9);  x ^= y; y = rw[16]; x += y; y = sum; rw[16] = x; y += x;
      ROTATE(x,13); x ^= y; y = rw[17]; x += y; y = sum; rw[17] = x; y += x;
      ROTATE(x,5);  x ^= y; y = rw[18]; x += y; y = sum; rw[18] = x; y += x;
      ROTATE(x,7);  x ^= y; y = rw[19]; x += y; y = sum; rw[19] = x; y += x;
      ROTATE(x,9);  x ^= y; y = rw[20]; x += y; y = sum; rw[20] = x; y += x;
      ROTATE(x,13); x ^= y; y = rw[21]; x += y;
      rw[21] = x;
      } while (--rounds);

   if (!++rw[2]) if (!++rw[3]) if (!++rw[4]) ++rw[5];
   rw[1] = 15;
   return(rw[21]);
   }
